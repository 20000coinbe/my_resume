package my.boardgame;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    boolean player_turn;
    int redCount=0, blueCount=0;

    int[] board={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int price[] = {0, 80000, 180000, 50000, 90000, 90000, 130000, 200000, 0, 90000, 150000, 80000, 80000, 90000, 90000, 70000};



    Button pushbtn;
    TextView text_p1_savemoney;
    TextView text_p2_savemoney;
    ImageView sample1, gaeseong, pyonyang, sinuiju, geumgangsan, seoul, incheon, daegu, daejeon, pohang, gwangju, yeosu, busan, ulsan, start, gangneung;
    GridLayout grid;
    LinearLayout L0,L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15;

    ImageView player_1,player_2;
    //위치//////////////////////////////////////////////////////////
    int position;

    //윷놀이//////////////////////////////////////////////////
    String[] yutName = {"모", "도", "개", "걸", "윷"};

    Random rnd = new Random();
    int[] yut = new int[4];

    int[] yutimg = {R.drawable.image1, R.drawable.image2};
    ImageView[] imgView = new ImageView[4];

    TextView txtResult;
    /////////////////////////////////////////////////////////

    //소지금/////////////////////////////////////////////////
    int money1;
    int money2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //버튼/////////////////////////////////////////////////////////////////////////
        pushbtn = (Button) findViewById(R.id.pushbtn);

        //보유금액 텍스트//////////////////////////////////////////////////////////////
        text_p1_savemoney = (TextView) findViewById(R.id.text_p1_savemoney);
        text_p2_savemoney = (TextView) findViewById(R.id.text_p2_savemoney);

        //이미지 뷰///////////////////////////////////////////////////////////////////
        grid = (GridLayout) findViewById(R.id.grid);
        sample1 = (ImageView) findViewById(R.id.sample1);
        gaeseong = (ImageView) findViewById(R.id.gaeseong);
        sinuiju = (ImageView) findViewById(R.id.sinuiju);
        geumgangsan = (ImageView) findViewById(R.id.geumgangsan);
        gangneung = (ImageView)findViewById(R.id.gangneung);
        seoul = (ImageView) findViewById(R.id.seoul);
        incheon = (ImageView) findViewById(R.id.incheon);
        daegu = (ImageView) findViewById(R.id.daegu);
        daejeon = (ImageView) findViewById(R.id.daejeon);
        pohang = (ImageView) findViewById(R.id.pohang);
        gwangju = (ImageView) findViewById(R.id.gwangju);
        yeosu = (ImageView) findViewById(R.id.yeosu);
        busan = (ImageView) findViewById(R.id.busan);
        start = (ImageView) findViewById(R.id.start);
        ulsan = (ImageView) findViewById(R.id.ulsan);

        //리니어 레이아웃///////////////////////////////////////////////////////////////
        L0 = (LinearLayout)findViewById(R.id.L0);
        L1 = (LinearLayout)findViewById(R.id.L1);
        L2 = (LinearLayout)findViewById(R.id.L2);
        L3 = (LinearLayout)findViewById(R.id.L3);
        L4 = (LinearLayout)findViewById(R.id.L4);
        L5 = (LinearLayout)findViewById(R.id.L5);
        L6 = (LinearLayout)findViewById(R.id.L6);
        L7 = (LinearLayout)findViewById(R.id.L7);
        L8 = (LinearLayout)findViewById(R.id.L8);
        L9 = (LinearLayout)findViewById(R.id.L9);
        L10 = (LinearLayout)findViewById(R.id.L10);
        L11 = (LinearLayout)findViewById(R.id.L11);
        L12 = (LinearLayout)findViewById(R.id.L12);
        L13 = (LinearLayout)findViewById(R.id.L13);
        L14 = (LinearLayout)findViewById(R.id.L14);
        L15 = (LinearLayout)findViewById(R.id.L15);

        //플레이어블 캐릭터 이미지///////////////////////////////////////////////////////
        player_1 = (ImageView) findViewById(R.id.player_1);
        player_2 = (ImageView) findViewById(R.id.player_2);

        //시작 위치///////////////////////////////////////////////////////////////////////
        player_1.setX(750);
        player_1.setY(750);

        player_2.setX(750);
        player_2.setY(750);

        txtResult = (TextView) findViewById(R.id.textResult);

        for (int i = 0; i < 4; i++) {
            imgView[i] = (ImageView) findViewById(R.id.imageView0 + i);
        }

        money1 = 100000;
        money2 = 100000;

        pushbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int player_result = setGameResult();
                if (!player_turn) {
                    movePlayer1(player_result);
                    count_red(player_result);
                    if (board[redCount] == 0){
                        buyBoard1();
                    }else if(board[redCount]==2){
                        buyBoard1();
                    }
                    player_turn = true;
                }
                else {
                    movePlayer2(player_result);
                    count_blue(player_result);
                    if (board[blueCount] == 0){
                        buyBoard2();
                    }else if(board[blueCount]==1){
                        buyBoard2();
                    }
                    player_turn = false;
                }
            }
        });
    }
    //윷놀이 구현 함수/////////////////////////////////////////////////////////////////////////////
    private int setGameResult() {
        int s = 0;

        for(int i = 0; i < 4; i++) {
            int n = rnd.nextInt(2);
            s += n;
            imgView[i].setImageResource(yutimg[n]);
        }
        //0 - 모 // 1 - 도 // 2 - 개 // 3 - 걸 // 4 - 윷
        txtResult.setText(yutName[s]);
        return s;
    }
    //나온 윷 모양에 따라서 P1이 움직일 횟수 ///////////////////////////////////////////////////////
    public int movePlayer1(int playerResult) {
        switch (playerResult) {
            case 0:
                moveplayer1Position();
                moveplayer1Position();
                moveplayer1Position();
                moveplayer1Position();
                moveplayer1Position();
                Toast.makeText(getApplicationContext(), "모 +1전진", Toast.LENGTH_SHORT).show();
                break;

            case 1:
                moveplayer1Position();
                break;

            case 2:
                moveplayer1Position();
                moveplayer1Position();
                break;

            case 3:
                moveplayer1Position();
                moveplayer1Position();
                moveplayer1Position();
                break;

            case 4:
                moveplayer1Position();
                moveplayer1Position();
                moveplayer1Position();
                moveplayer1Position();
                break;

        }
        return  position;
    }

    //나온 윷 모양에 따라서 P2이 움직일 횟수 ///////////////////////////////////////////////////////
    public int movePlayer2(int playerResult) {
        switch (playerResult) {
            case 0:
                moveplayer2Position();
                moveplayer2Position();
                moveplayer2Position();
                moveplayer2Position();
                moveplayer2Position();
                Toast.makeText(getApplicationContext(), "모 +1전진", Toast.LENGTH_SHORT).show();
                break;
            case 1:
                moveplayer2Position();
                break;
            case 2:
                moveplayer2Position();
                moveplayer2Position();
                break;
            case 3:
                moveplayer2Position();
                moveplayer2Position();
                moveplayer2Position();
                break;
            case 4:
                moveplayer2Position();
                moveplayer2Position();
                moveplayer2Position();
                moveplayer2Position();
                break;
        }
        return position;
    }


    // 말 위치 좌표변환 P1///////////////////////////////////////////////////////////////////////////
    private void moveplayer1Position() {
        if (player_1.getX() >= 187 && player_1.getX() <= 750 && player_1.getY() == 750) {
            player_1.setX(player_1.getX() - 187);
        } else if (player_1.getX() == 2 && player_1.getY() >= 187 && player_1.getY() <= 750) {
            player_1.setY(player_1.getY() - 187);
        } else if (player_1.getX() >= 2 && player_1.getX() <= 563 && player_1.getY() == 2) {
            player_1.setX(player_1.getX() + 187);
        } else if (player_1.getX() == 750 && player_1.getY() >= 2 && player_1.getY() <= 563) {
            player_1.setY(player_1.getY() + 187);
        }
    }

    // 말 위치 좌표변환 P2///////////////////////////////////////////////////////////////////////////
    private void moveplayer2Position() {
        if (player_2.getX() >= 187 && player_2.getX() <= 750 && player_2.getY() == 750) {
            player_2.setX(player_2.getX() - 187);
        } else if (player_2.getX() == 2 && player_2.getY() >= 187 && player_2.getY() <= 750) {
            player_2.setY(player_2.getY() - 187 );
        } else if (player_2.getX() >= 2  && player_2.getX() <= 563  && player_2.getY() == 2 ) {
            player_2.setX(player_2.getX() + 187 );
        } else if (player_2.getX() == 750  && player_2.getY() >= 2  && player_2.getY() <= 563 ) {
            player_2.setY(player_2.getY() + 187 );
        }
    }
    //P1이 움직인 말의 횟수만큼 redCount의 값을 증가시켜주는 함수/////////////////////////////////
    public void count_red(int playerResult){
        redCount = (redCount + playerResult) % 16;
    }
    //P2가 움직인 말의 횟수만큼 blueCount의 값을 증가시켜주는 함수/////////////////////////////////
    public void count_blue(int playerResult){
        blueCount = (blueCount + playerResult) % 16;
    }

    //P1 땅구매 함수/////////////////////////////////////////////////////////////
    public void buyBoard1(){
        int current_money;
        if(board[redCount] == 0){
            board[redCount] = 1;
            changeColor1();
        }

        current_money = Integer.parseInt(text_p1_savemoney.getText().toString());
        if(current_money < price[redCount]){
            Toast.makeText(getApplicationContext(),"2P의 승리입니다.",Toast.LENGTH_LONG).show();
            finish();
        }
        int result = current_money - price[redCount];
        text_p1_savemoney.setText(String.valueOf(result));
    }

    //P2 땅구매 함수/////////////////////////////////////////////////////////////
    public void buyBoard2(){
        int current_money;
        if(board[blueCount]==0) {
            board[blueCount] = 2;
            changeColor2();
        }
        current_money = Integer.parseInt(text_p2_savemoney.getText().toString());
        if (current_money < price[blueCount]) {
            Toast.makeText(getApplicationContext(),"1P의 승리입니다.",Toast.LENGTH_LONG).show();
            finish();
        }
        int result = current_money - price[blueCount];
        text_p2_savemoney.setText(String.valueOf(result));
    }

    //P1 구매 보드판 색변환 함수///////////////////////////////////////////////////////////////
    public void changeColor1(){
        if(board[redCount]==1) {
            switch(redCount) {
                case 0:
                    break;
                case 1:
                    L14.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 2:
                    L13.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 3:
                    L12.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 4:
                    L11.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 5:
                    L9.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 6:
                    L7.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 7:
                    L5.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 8:
                    break;
                case 9:
                    L1.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 10:
                    L2.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 11:
                    L3.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 12:
                    L4.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 13:
                    L6.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 14:
                    L8.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
                case 15:
                    L10.setBackgroundColor(Color.parseColor("#ff00ff"));
                    break;
            }
        }
    }
    //P2 구매 보드판 색변환 함수///////////////////////////////////////////////////////////////
    public void changeColor2(){
        if(board[blueCount]==2) {
            switch(blueCount) {
                case 0:
                    break;
                case 1:
                    L14.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 2:
                    L13.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 3:
                    L12.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 4:
                    L11.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 5:
                    L9.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 6:
                    L7.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 7:
                    L5.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 8:
                    break;
                case 9:
                    L1.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 10:
                    L2.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 11:
                    L3.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 12:
                    L4.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 13:
                    L6.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 14:
                    L8.setBackgroundColor(Color.parseColor("#414284"));
                    break;
                case 15:
                    L10.setBackgroundColor(Color.parseColor("#414284"));
                    break;
            }
        }
    }
}
