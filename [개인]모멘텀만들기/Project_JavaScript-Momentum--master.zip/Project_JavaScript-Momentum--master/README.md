# Project_JavaScript
모멘텀 만들어보기

1. 시계
2. 할일(toDoList) - 생성, 삭제
3. 날씨정보(화씨, 지역) : OpenWeatherMap API 활용
4. 전환되는 배경화면
